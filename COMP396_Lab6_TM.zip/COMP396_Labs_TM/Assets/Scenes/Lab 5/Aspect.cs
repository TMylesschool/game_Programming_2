using UnityEngine;
public class Aspect : MonoBehaviour
{
    public enum Affiliation
    {
        Player,
        Enemy
    }
    public Affiliation affiliation;
}